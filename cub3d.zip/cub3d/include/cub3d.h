/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   cub3d.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: noldiane <noldiane@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/05 16:26:06 by noldiane          #+#    #+#             */
/*   Updated: 2024/11/07 14:40:39 by noldiane         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef CUB3D_H
#define CUB3D_H

/* LIBRARIES */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

# include "errors.h"
# include "libft.h"
# include "mlx.h"
# include "mlx_int.h"

/* DATA */

# define WIN_WIDTH 640
# define WIN_HEIGHT 480

/* STRUCTURES */

typedef struct s_game
{
	char	**map;

	char	*F_COLOR;
	char	*C_COLOR;

	char	*NO_TEXTURE;
	char	*SO_TEXTURE;
	char	*WE_TEXTURE;
	char	*EA_TEXTURE;
} t_game;

/* FUNCTIONS */

int parse_arguments(int argc, char *argv[]);

void	init_game_instance(t_game **game);
void	init_game(const int fd, t_game *game);

#endif
