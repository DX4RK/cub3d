#ifndef ERRORS_H
#define ERRORS_H

# define ERROR_MISSING_CUB "Error, missing .cub file, or too may arguments!"
# define ERROR_WRONG_FORMAT "Error, wrong file format!"
# define FILE_NOT_EXIST "Error, this file does not exist, or not enough permission to read file!"

#endif
