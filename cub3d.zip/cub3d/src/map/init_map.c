/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   init_map.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: noldiane <noldiane@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/07 14:14:18 by noldiane          #+#    #+#             */
/*   Updated: 2024/11/11 13:12:19 by noldiane         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

void	init_map_array(const int fd, t_game *game, int line_count)
{
	game->map = malloc(sizeof(char **) * line_count);

	char	*line;
	int		current_index;

	current_index = 0;
	while (((line = get_next_line(fd, 0)) != NULL) && line_count <= current_index)
	{
		printf("%s\n", line);
		if (line[0] == '1')
		{
			printf("%s\n", line);
			game->map[current_index] = ft_strdup(line);
		}
	}
}
