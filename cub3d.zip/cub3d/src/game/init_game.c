/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   init_game.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: noldiane <noldiane@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/07 14:32:13 by noldiane          #+#    #+#             */
/*   Updated: 2024/11/07 14:45:22 by noldiane         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

void	init_game(const int fd, t_game *game)
{
    char	*line;
	
	while ((line = get_next_line(fd)) != NULL)
	{
		if (line[0] == 'F')
			game->F_COLOR = ft_substr(line, 2, ft_strlen(line) - 2);

	}
}