/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   init.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: noldiane <noldiane@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/07 14:20:33 by noldiane          #+#    #+#             */
/*   Updated: 2024/11/08 11:34:02 by noldiane         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

void	init_instance(t_game *game)
{
	game->map = NULL;
	game->F_COLOR = NULL;
	game->C_COLOR = NULL;
	game->NO_TEXTURE = NULL;
	game->SO_TEXTURE = NULL;
	game->WE_TEXTURE = NULL;
	game->EA_TEXTURE = NULL;
}

void	init_game_instance(t_game **game)
{
	*game = malloc(sizeof(t_game));
	if (!(*game))
	{
		perror("malloc");
		exit (EXIT_FAILURE);
	}
	init_instance(*game);
}